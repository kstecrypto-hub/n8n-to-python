---
name: codex-architecture-guardrails
description: review software tasks, feature requests, refactor requests, and codex prompts before implementation to prevent architecture drift, god files, weak boundaries, and unsafe ai agent or rag designs. use when chatgpt is asked to help codex modify a codebase, generate an implementation prompt, review an ai agent or rag architecture, or create a refactor plan for backend, retrieval, memory, tool-calling, sessions, workers, or frontend boundaries.
---

# Codex Architecture Guardrails

Use this skill to convert a user request or an existing Codex prompt into an architecture-safe implementation plan and a Codex-ready prompt. Apply it before every substantial coding task, especially in AI agent, RAG, chat runtime, retrieval, memory, ingestion, worker, or tool-calling systems.

## Default workflow

1. Identify the requested change.
2. Classify the task:
   - **feature work**
   - **bug fix**
   - **refactor**
   - **architecture review**
   - **prompt review for codex**
3. Build a quick architecture inventory:
   - which modules will change
   - which bounded contexts are involved
   - which stores, queues, or external systems are touched
   - whether the task is on the online serving path or the offline job path
4. Detect architectural risks before proposing code.
5. Produce all of the following unless the user explicitly asks for less:
   - a concise review report
   - a list of architecture violations or risks
   - a refactor or implementation plan
   - a Codex-ready prompt
6. Prefer extraction, separation of responsibilities, and explicit contracts over “just append logic to the nearest file”.

## Required pre-flight checks

Before proposing implementation steps, always answer these questions:

1. **What is the real subsystem?**
   Do not trust legacy filenames or package names. Determine whether the change belongs to serving, retrieval, ingestion, identity, memory, admin, frontend, or a domain-specific module.

2. **Is this an online-path concern or an offline-path concern?**
   - Online path: request handling, chat runtime, retrieval, session resolution, authz, answer generation.
   - Offline path: ingestion, indexing, repair, backfills, evaluation jobs, maintenance, reprocessing.
   These should not be mixed casually.

3. **Is the system actually agentic?**
   Distinguish between:
   - deterministic orchestration around an LLM, and
   - autonomous tool-using multi-step agents.
   Do not recommend multi-agent patterns unless the task truly requires them.

4. **What is the source of truth?**
   Identify canonical storage vs derived indexes/caches. For RAG systems, retrieved indexes are usually derived, not canonical truth.

5. **Which boundaries must not be crossed?**
   Examples:
   - route handlers must not become business-logic containers
   - repositories must not own schema mutation or hidden startup repair
   - page components must not hold domain logic
   - retrieval modules must not own session policy
   - ingestion workers must not be coupled to request latency paths

## Architecture rules

### Keep modular-monolith discipline unless there is a strong operational reason not to

Default recommendation:
- keep one repo
- keep one main app/backend process for request-serving concerns
- keep one worker/job process for ingestion and other offline tasks
- avoid splitting retrieval, chat runtime, and core agent orchestration into separate network services unless independent scaling, ownership, or security constraints clearly require it

### Prefer explicit stage boundaries for AI systems

For RAG or chat-runtime code, encourage a staged flow such as:
1. request guard
2. conversation/session resolution
3. planner or routing stage
4. retrieval orchestration
5. evidence packing and budget management
6. prompt assembly
7. model generation
8. grounding or citation verification
9. trace/memory recording

A single orchestrator is fine. A single god function is not.

### Treat memory as a subsystem, not a side effect

Require explicit memory classes where relevant:
- session continuity
- user preferences
- user self-reported facts
- open threads or tasks
- operator corrections

Do not blur retrieved corpus facts into “memory”.
Do not allow arbitrary model output to become durable memory without rules.

### Separate platform logic from domain logic

For agent or RAG systems, separate generic platform concerns from domain-specific logic.
Examples:
- platform: sessions, retrieval, authz, citations, ingestion, workers
- domain: sensor interpretation, business scoring, report semantics, workflow-specific reasoning

### Use repositories narrowly

Repository layers should:
- encapsulate persistence access
- be split by bounded context
- not perform hidden schema migration, repair, or startup side effects in constructors

### Keep route handlers thin

Route files should primarily:
- validate request shape
- call a service or orchestrator
- shape the response

They should not become the app kernel or operational control plane.

### Do not add logic to overloaded files without extraction first

Treat the following as strong warnings:
- files that already own multiple unrelated responsibilities
- oversized service/controller/repository files
- frontend pages with heavy domain transformation
- utility modules that are actually hidden dumping grounds

When a target file is already overloaded, recommend extraction before extension.

## AI agent and RAG review heuristics

Use these heuristics when the task involves LLM apps.

### Healthy patterns
- deterministic orchestration around retrieval and generation
- explicit scoping by tenant, workspace, user, document, or profile
- clear online/offline separation
- traces and replayability
- source-of-truth clarity
- citation or grounding checks
- bounded tool usage

### Warning signs
- “agent” file that is really a giant pipeline container
- retrieval strategy, memory policy, session policy, and generation logic all fused together
- free-form tool-calling proposed where deterministic routing is enough
- indexes treated as canonical truth
- ingestion coupled to request-serving path
- page component acting as application core
- repository or utility module acting as a god object
- adding features by copying existing drift instead of correcting boundaries

### Guidance on agentic architecture
- Do not recommend multi-agent decomposition just because the code is messy.
- First ask whether the system is actually a controlled RAG pipeline.
- If the system is mostly deterministic orchestration, optimize for stage separation, observability, and boundary clarity before adding autonomy.
- Add planner-like model reasoning only under bounded outputs and validated execution paths.

## Output contract

Unless the user explicitly requests a smaller answer, produce these sections in order:

### 1. Architecture read
Briefly state what the system or target module actually is.
Example: “This is a deterministic RAG orchestration service, not an autonomous multi-agent runtime.”

### 2. What is wrong
List the most important architectural issues, prioritized by impact.
Focus on responsibility overload, bad boundaries, hidden coupling, source-of-truth confusion, and unsafe agentic assumptions.

### 3. What to change
Give concrete structural recommendations:
- what stays in-process
- what moves to a worker
- what must be extracted into modules/services
- what should remain deterministic
- what should not become a separate microservice yet

### 4. Refactor or implementation plan
Give an ordered plan with minimal unnecessary churn.
Prefer extraction and relocation over rewrites.

### 5. Codex prompt
Provide a technical, implementation-ready prompt that:
- explains the real architecture
- explains why the current shape is wrong
- sets constraints on what not to do
- tells Codex how to refactor or implement safely

## Codex prompt requirements

When generating a prompt for Codex:
- state the architectural interpretation explicitly
- name the overloaded modules or boundaries
- state the target module boundaries
- tell Codex not to convert deterministic orchestration into a multi-agent system unless asked
- tell Codex not to introduce microservices by default
- tell Codex to preserve behavior unless a bug is intentionally fixed
- require an inventory of overloaded files before edits
- require explanation for any new module added
- prefer extraction over extension of god files

## Response style

Be direct and technical.
Name the architectural tradeoffs.
Do not praise drift just because the code works.
Do not recommend heavy distributed architecture unless justified.
For AI systems, distinguish clearly between:
- orchestration pipeline
- tool-using agent
- background worker
- retrieval subsystem
- memory subsystem
- domain-specific reasoning layer

## Optional deepening questions

Ask follow-up questions only when they materially change the recommendation, such as:
- whether ingestion is operator-triggered or continuous
- whether retrieval is latency-sensitive on the online path
- whether multiple teams deploy subsystems independently
- whether the system serves multiple products or only one

If the likely answer does not materially change the recommendation, proceed with best-effort guidance instead of blocking on questions.
