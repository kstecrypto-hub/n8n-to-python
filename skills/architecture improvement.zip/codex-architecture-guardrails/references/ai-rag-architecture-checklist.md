# AI Agent and RAG Architecture Checklist

Use this checklist when reviewing a task, repo, or Codex prompt.

## System identification
- Is this actually an autonomous agent, or a deterministic orchestration layer around an LLM?
- Which parts are online-path vs offline-path?
- What are the canonical stores?
- Which stores are derived or disposable?

## Boundary checks
- Are route handlers thin?
- Are repositories persistence-focused only?
- Is retrieval separate from session and memory policy?
- Is domain logic separate from platform logic?
- Is ingestion isolated from serving latency paths?

## Serving-path checks
- Is there a clear stage flow from request guard through generation and recording?
- Are authz, scope, and tenancy enforced before retrieval and generation?
- Is evidence packed explicitly with budget/provenance control?
- Is there grounding, citation, or abstention logic?

## Memory checks
- Are memory types distinguished?
- Are memory writes controlled?
- Can memory be inspected and deleted?
- Is retrieved corpus truth kept separate from user memory?

## Warning signs
- giant service/controller/repository files
- utility modules acting as hidden god layers
- page components with domain algorithms
- adding features to the nearest loaded file instead of the correct subsystem
- microservice proposals without operational justification
