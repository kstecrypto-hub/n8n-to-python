# Codex Prompt Template

Use this template when turning an architecture review into an implementation prompt.

## Task framing
- The system is: [deterministic rag orchestration / chat runtime / worker-based ingestion system / etc]
- It is not: [autonomous multi-agent runtime / microservice mesh / etc]

## Current problems
- [problem 1]
- [problem 2]
- [problem 3]

## Constraints
- preserve behavior unless explicitly fixing a bug
- do not rewrite from scratch
- do not introduce microservices by default
- do not introduce multi-agent loops unless explicitly requested
- prefer extraction over extension of overloaded files

## Required inventory before editing
Identify the top overloaded files and explain which responsibilities should leave each one.

## Target structure
Describe the target module boundaries and ownership clearly.

## Execution plan
Give incremental steps, compatibility notes, and required test updates.
